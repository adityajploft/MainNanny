import React from 'react'

const MyPlan = () => {
  return (
    <div>MyPlan</div>
  )
}

export default MyPlan