import React from 'react'

function OtherService() {
  return (
    <div>OtherService</div>
  )
}

export default OtherService